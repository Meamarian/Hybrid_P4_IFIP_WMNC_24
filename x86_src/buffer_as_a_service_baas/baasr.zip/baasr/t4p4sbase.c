// SPDX-License-Identifier: Apache-2.0
// Copyright 2018 Eotvos Lorand University, Budapest, Hungary

#include <rte_ethdev.h>
#include <rte_hash_crc.h>
#include <rte_ring.h>

#include "dpdk_nicon.h"
#include "dpdkx_crypto.h"
#include "dataplane_hdr_fld_pkt.h"
#include <rte_hash.h>
#include <rte_jhash.h>

#include "util_packet.h"
#include "util_debug.h"

//#define RTE_LOGTYPE_APP RTE_LOGTYPE_USER1

static const char *_MSG_POOL = "MSG_POOL0";
//static const char *_MSG_POOL = "MSG_POOL";
#define STR_TOKEN_SIZE 128
static const char *_SEC_2_PRI = "SEC_2_PRI";
static const char *_PRI_2_SEC1 = "PRI_2_SEC1";
static const char *_PRI_2_SEC2 = "PRI_2_SEC2";
static const char *_PRI_2_SEC3 = "PRI_2_SEC3";
//#define STR_TOKEN_SIZE 128
typedef struct rte_hash lookup_struct_t;

static lookup_struct_t *buffer_table;
static struct rte_hash_parameters ut_params = {
    .name = "BufferTable1",
    .entries = 1024*256,
    .key_len = sizeof(uint64_t),
    //.hash_func = rte_jhash,
    //.extra_flag=RTE_HASH_EXTRA_FLAGS_EXT_TABLE,
    //.extra_flag=RTE_HASH_EXTRA_FLAGS_RW_CONCURRENCY,
    //.socket_id = 0,
};

struct rte_ring *send_ring1,*send_ring2,*send_ring3, *recv_ring;
struct rte_mempool *message_pool;
volatile int quit = 0;
const unsigned flags = 0;
const unsigned ring_size = 2097152*8*4;
const unsigned pool_size = 10000000;
const unsigned pool_cache = 32*10;
const unsigned priv_data_sz = 0;
struct rte_mbuf* cloned_pkts[MAX_PKT_BURST];
struct rte_mbuf* cloned_pkt;
struct rte_mbuf* m;
struct rte_mbuf* m1;
int ret;
int j;
//unsigned lcore_id;

extern int get_socketid(unsigned lcore_id);

extern struct lcore_conf lcore_conf[RTE_MAX_LCORE];
extern void dpdk_init_nic();
extern uint8_t get_nb_ports();

// ------------------------------------------------------
// Locals

struct rte_mempool *header_pool, *clone_pool,*my_clone_pool;;
extern struct rte_mempool* pktmbuf_pool[NB_SOCKETS];

struct rte_mbuf* deparse_mbuf;

// ------------------------------------------------------

/* Send burst of packets on an output interface */
static inline void send_burst(struct lcore_conf *conf, uint16_t n, uint8_t port)
{
    uint16_t queueid = conf->hw.tx_queue_id[port];
    struct rte_mbuf **m_table = (struct rte_mbuf **)conf->hw.tx_mbufs[port].m_table;

    int ret = rte_eth_tx_burst(port, queueid, m_table, n);
    if (unlikely(ret < n)) {
        do {
            rte_pktmbuf_free(m_table[ret]);
        } while (++ret < n);
    }
}

void tx_burst_queue_drain(LCPARAMS) {
    uint64_t cur_tsc = rte_rdtsc();

    uint64_t diff_tsc = cur_tsc - lcdata->prev_tsc;
    if (unlikely(diff_tsc > lcdata->drain_tsc)) {
        for (unsigned portid = 0; portid < get_nb_ports(); portid++) {
            if (lcdata->conf->hw.tx_mbufs[portid].len == 0)
                continue;

            send_burst(lcdata->conf,
                       lcdata->conf->hw.tx_mbufs[portid].len,
                       (uint8_t) portid);
            lcdata->conf->hw.tx_mbufs[portid].len = 0;
        }

        lcdata->prev_tsc = cur_tsc;
    }
}

// ------------------------------------------------------

static uint16_t
add_packet_to_queue(struct rte_mbuf *mbuf, uint8_t port, uint32_t lcore_id)
{
    struct lcore_conf *conf = &lcore_conf[lcore_id];
    uint16_t queue_length = conf->hw.tx_mbufs[port].len;
    conf->hw.tx_mbufs[port].m_table[queue_length] = mbuf;
    queue_length++;

    return queue_length;
}


/* creating replicas of a packet for  */
static inline struct rte_mbuf *
mcast_out_pkt(struct rte_mbuf *pkt, int use_clone)
{
    struct rte_mbuf *hdr;

    debug("mcast_out_pkt new mbuf is needed...\n");
        /* Create new mbuf for the header. */
        if ((hdr = rte_pktmbuf_alloc(header_pool)) == NULL)
                return (NULL);

    debug("hdr is allocated\n");

    /* If requested, then make a new clone packet. */
    if (use_clone != 0 &&
        (pkt = rte_pktmbuf_clone(pkt, clone_pool)) == NULL) {
            rte_pktmbuf_free(hdr);
            return (NULL);
    }

    debug("setup ne header\n");

    /* prepend new header */
    hdr->next = pkt;


    /* update header's fields */
    hdr->pkt_len = (uint16_t)(hdr->data_len + pkt->pkt_len);
    hdr->nb_segs = (uint8_t)(pkt->nb_segs + 1);

    /* copy metadata from source packet*/
    hdr->port = pkt->port;
    hdr->vlan_tci = pkt->vlan_tci;
    hdr->vlan_tci_outer = pkt->vlan_tci_outer;
    hdr->tx_offload = pkt->tx_offload;
    hdr->hash = pkt->hash;

    hdr->ol_flags = pkt->ol_flags;

    __rte_mbuf_sanity_check(hdr, 1);
    return (hdr);
}

// ------------------------------------------------------

static void dpdk_send_packet(struct rte_mbuf *mbuf, uint8_t port, uint32_t lcore_id)
{
    struct lcore_conf *conf = &lcore_conf[lcore_id];
    uint16_t queue_length = add_packet_to_queue(mbuf, port, lcore_id);

    if (unlikely(queue_length == MAX_PKT_BURST)) {
        debug("    :: BURST SENDING DPDK PACKETS - port:%d\n", port);
        send_burst(conf, MAX_PKT_BURST, port);
        queue_length = 0;
    }

    conf->hw.tx_mbufs[port].len = queue_length;
}

/* Enqueue a single packet, and send burst if queue is filled */
void send_single_packet(packet* pkt, int egress_port, int ingress_port, bool send_clone, LCPARAMS)
{
    uint32_t lcore_id = rte_lcore_id();
    struct rte_mbuf* mbuf = (struct rte_mbuf *)pkt;

    dpdk_send_packet(mbuf, egress_port, lcore_id);
}

// ------------------------------------------------------

void init_queues(struct lcore_data* lcdata) {
    for (unsigned i = 0; i < lcdata->conf->hw.n_rx_queue; i++) {
        unsigned portid = lcdata->conf->hw.rx_queue_list[i].port_id;
        uint8_t queueid = lcdata->conf->hw.rx_queue_list[i].queue_id;
        RTE_LOG(INFO, P4_FWD, " -- lcoreid=%u portid=%u rxqueueid=%hhu\n", rte_lcore_id(), portid, queueid);
    }
}

extern void init_async_data(struct lcore_data *data);
extern void init_crypto_data(struct lcore_data *data);


struct lcore_data init_lcore_data() {
    struct lcore_data lcdata = {
        .drain_tsc = (rte_get_tsc_hz() + US_PER_S - 1) / US_PER_S * BURST_TX_DRAIN_US,
        .prev_tsc  = 0,

        .conf     = &lcore_conf[rte_lcore_id()],
        .mempool  = pktmbuf_pool[get_socketid(rte_lcore_id())], // TODO: Check for MULTI-SOCKET CASE !!!!

        .is_valid  = lcdata.conf->hw.n_rx_queue != 0,
    };
    lcdata.conf->mempool  = pktmbuf_pool[0]; // pktmbuf_pool[rte_lcore_id()] + get_socketid(rte_lcore_id());
    #if ASYNC_MODE != ASYNC_MODE_OFF
        init_async_data(&lcdata);
    #endif
    #if T4P4S_INIT_CRYPTO
        init_crypto_data(&lcdata);
    #endif
    if (lcdata.is_valid) {
        RTE_LOG(INFO, P4_FWD, "entering main loop on lcore %u\n", rte_lcore_id());

        init_queues(&lcdata);
    } else {
        RTE_LOG(INFO, P4_FWD, "lcore %u has nothing to do\n", rte_lcore_id());
    }

    return lcdata;
}

// ------------------------------------------------------

bool check_packet_after_parse(LCPARAMS) {
    return true;
}

bool core_is_working(LCPARAMS) {
    return true;
}

bool is_packet_handled(LCPARAMS) {
    return true;
}

// Function to calculate CRC hash value from source and destination IP addresses
// uint32_t calculate_crc_hash(uint32_t src_ip, uint32_t dst_ip) {
//     uint64_t addr_pair = ((uint64_t)src_ip << 32) | dst_ip;
//     return rte_hash_crc_4byte(&addr_pair, 0);
// }

uint32_t calculate_fnv_hash(uint32_t src_ip, uint32_t dst_ip) {
    uint64_t addr_pair = ((uint64_t)src_ip << 32) | dst_ip;
    uint32_t hash = 2166136261;
    hash = (hash ^ addr_pair) * 16777219;
    return hash;
}

#define PHYSICAL_BUFFER_H_SIZE sizeof(struct physical_buffer_h)

struct physical_buffer_h {
    uint8_t nack_count;
    uint32_t endpoint_id;
    uint16_t ack_sn;
    uint16_t pf_number;
};

bool receive_packet(unsigned pkt_idx, LCPARAMS) {
    packet* p = lcdata->pkts_burst[pkt_idx];
    rte_prefetch0(rte_pktmbuf_mtod(p, void *));

    struct rte_ipv4_hdr *ipv4_hdr = rte_pktmbuf_mtod_offset(p, struct rte_ipv4_hdr *, sizeof(struct rte_ether_hdr));
    struct rte_udp_hdr *udp_hdr = (struct rte_udp_hdr *)((char *)ipv4_hdr + sizeof(struct rte_ipv4_hdr));

    if (rte_be_to_cpu_16(udp_hdr->src_port) == 2152 | rte_be_to_cpu_16(udp_hdr->src_port) == 8040|rte_be_to_cpu_16(udp_hdr->src_port) == 2153) {

        // Clone the packet if necessary
        struct rte_mbuf *cloned_pkt = rte_pktmbuf_clone(p, my_clone_pool);
        if (cloned_pkt != NULL) {
            uint32_t src_ip = rte_be_to_cpu_32(ipv4_hdr->src_addr);
            // uint32_t dst_ip = rte_be_to_cpu_32(ipv4_hdr->dst_addr);
            // uint32_t crc_hash_value = calculate_fnv_hash(src_ip, dst_ip);
                // uint32_t key = 1;
                // uint32_t value = 12345;
                //int ret = rte_hash_add_key_data(buffer_table, &src_ip, (void *)m);
                int ret =rte_hash_add_key_with_hash_data(buffer_table, &src_ip, 0,(void *)m);
                if (ret < 0) {
                    printf("Error inserting key %u\n", src_ip);
                }
        //    if (crc_hash_value % 2 == 0) {
                rte_ring_enqueue(send_ring1, (void *) cloned_pkt);
            // } else {
            //     rte_ring_enqueue(send_ring2, (void *) cloned_pkt);
            // }
        }
    }

    pd->data = rte_pktmbuf_mtod(p, uint8_t *);
    pd->wrapper = p;
    return true;
}

void free_packet(LCPARAMS) {
    rte_pktmbuf_free(pd->wrapper);
}

// defined in main_async.c
void async_init_storage();

void init_storage() {
    /* Needed for L2 multicasting - e.g. acting as a hub
        cloning headers and sometimes packet data*/
    header_pool = rte_pktmbuf_pool_create("header_pool", NB_HDR_MBUF, 32,
            0, HDR_MBUF_DATA_SIZE, rte_socket_id());

    if (header_pool == NULL)
        rte_exit(EXIT_FAILURE, "Cannot init header mbuf pool\n");

    clone_pool = rte_pktmbuf_pool_create("clone_pool", NB_CLONE_MBUF, 32,
            0, 0, rte_socket_id());

    my_clone_pool = rte_pktmbuf_pool_create("my_clone_pool", 50000000, 32*10,
            0, HDR_MBUF_DATA_SIZE, rte_socket_id());

    if (clone_pool == NULL)
        rte_exit(EXIT_FAILURE, "Cannot init clone mbuf pool\n");

    if (my_clone_pool == NULL)
        rte_exit(EXIT_FAILURE, "Cannot init my clone mbuf pool\n");

    send_ring1 = rte_ring_create(_PRI_2_SEC1, ring_size, rte_socket_id(),flags);
    send_ring2 = rte_ring_create(_PRI_2_SEC2, ring_size, rte_socket_id(),flags); //RING_F_SP_ENQ | RING_F_SC_DEQ

    // message_pool = rte_mempool_create(_MSG_POOL, pool_size,
    //         STR_TOKEN_SIZE, pool_cache, priv_data_sz,
    //         NULL, NULL, NULL, NULL,
    //         rte_socket_id(), flags);

    //     //Create Hash table

    ut_params.socket_id = 0;
				
    buffer_table = rte_hash_create(&ut_params);
    if (buffer_table == NULL) {
        printf("UNABLE TO CREATE HASHTABLE\n");
        rte_exit(EXIT_FAILURE, "UNABLE TO CREATE HASHTABLE\n");
    }

    // Insert a single key-value pair into the hash table


    // const struct rte_memzone *mz;
    // mz = rte_memzone_reserve("shared_hash_table_zone", sizeof(buffer_table), rte_socket_id(), 0);
    // if (mz == NULL) {
    //     rte_exit(EXIT_FAILURE, "Cannot reserve memory zone\n");
    // }

    // //memcpy(mz->addr, buffer_table, sizeof(buffer_table));
    // struct rte_hash **hash_table_ptr = mz->addr;
    // *hash_table_ptr = buffer_table;


    // uint32_t teid =0;

    //  rte_hash_add_key_data(buffer_table, &teid, (void * )m1);
    //send_ring3 = rte_ring_create(_PRI_2_SEC3, ring_size, rte_socket_id(), flags);

    if (clone_pool == NULL)
        rte_exit(EXIT_FAILURE, "Cannot init clone mbuf pool\n");
    #if ASYNC_MODE != ASYNC_MODE_OFF
        async_init_storage();
    #endif
}

void main_loop_pre_rx(LCPARAMS) {
    tx_burst_queue_drain(LCPARAMS_IN);
}

void main_loop_post_rx(bool got_packet, LCPARAMS) {
}

#if defined ASYNC_MODE && ASYNC_MODE != ASYNC_MODE_OFF
    void main_loop_pre_single_rx_async(LCPARAMS);
    void main_loop_post_single_rx_async(bool got_packet, LCPARAMS);
    void main_loop_pre_single_tx_async(LCPARAMS);
    void main_loop_post_single_tx_async(LCPARAMS);
#endif

void main_loop_pre_single_rx(LCPARAMS){
    #if defined ASYNC_MODE && ASYNC_MODE != ASYNC_MODE_OFF
        main_loop_pre_single_rx_async(LCPARAMS_IN);
    #endif
}

void main_loop_post_single_rx(bool got_packet, LCPARAMS) {
    #if defined ASYNC_MODE && ASYNC_MODE != ASYNC_MODE_OFF
        main_loop_post_single_rx_async(got_packet, LCPARAMS_IN);
    #endif
}

void main_loop_pre_single_tx(LCPARAMS){
    #if defined ASYNC_MODE && ASYNC_MODE != ASYNC_MODE_OFF
        main_loop_pre_single_tx_async(LCPARAMS_IN);
    #endif
}
void main_loop_post_single_tx(LCPARAMS){
    #if defined ASYNC_MODE && ASYNC_MODE != ASYNC_MODE_OFF
        main_loop_post_single_tx_async(LCPARAMS_IN);
    #endif
}

uint32_t get_portid(unsigned queue_idx, LCPARAMS) {
    return lcdata->conf->hw.rx_queue_list[queue_idx].port_id;
}

void main_loop_rx_group(unsigned queue_idx, LCPARAMS) {
    uint8_t queue_id = lcdata->conf->hw.rx_queue_list[queue_idx].queue_id;
    lcdata->nb_rx = rte_eth_rx_burst((uint8_t) get_portid(queue_idx, LCPARAMS_IN), queue_id, lcdata->pkts_burst, MAX_PKT_BURST);
}

unsigned get_pkt_count_in_group(LCPARAMS) {
    return lcdata->nb_rx;
}

unsigned get_queue_count(LCPARAMS) {
    return lcdata->conf->hw.n_rx_queue;
}

void initialize_nic() {
    dpdk_init_nic();
    #if T4P4S_INIT_CRYPTO
        init_crypto_devices();
    #endif
}

int launch_count() {
    return 1;
}

void t4p4s_abnormal_exit(int retval, int idx) {
    debug(T4LIT(Abnormal exit,error) ", code " T4LIT(%d) ".\n", retval);
}

void t4p4s_after_launch(int idx) {
    debug(T4LIT(Execution done.,success) "\n");
}

int t4p4s_normal_exit() {
    debug(T4LIT(Normal exit.,success) "\n");
    return 0;
}

void t4p4s_pre_launch(int idx) {
    
}

void t4p4s_post_launch(int idx) {

}

extern uint32_t enabled_port_mask;
uint32_t get_port_mask() {
    return enabled_port_mask;
}

extern uint8_t get_nb_ports();
uint8_t get_port_count() {
    return get_nb_ports();
}

int get_packet_idx(LCPARAMS) {
    return -1;
}
